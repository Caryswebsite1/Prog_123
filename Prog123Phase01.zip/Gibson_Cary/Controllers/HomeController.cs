﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gibson_Cary.Models;

namespace Gibson_Cary.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Page2(Person person)
        {
           // send to the DB on Phase 2

            return View(person);
        }
    }
}
