﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gibson_Cary.Models
{
    public class Credentials
    {
        public String UserName { get; set; }
        public String PassWord { get; set; }
        public int UID { get; set; }
    }
}
