﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gibson_Cary.Models
{
    public class Product
    {
        // Name and Description max 50 char.  Nothing can be null.
        public String Name { get; set; }
        public String Description { get; set; }
        public float Price { get; set; }
        public int InventoryAmount { get; set; }
        public int PID { get; set; }

    }// end class
}// end namespace
