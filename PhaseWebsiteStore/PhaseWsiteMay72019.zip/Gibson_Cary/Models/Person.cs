﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gibson_Cary.Models
{
    public class Person
    {
        public String FName { get; set; }
        public String LName { get; set; }
        public String Email { get; set; }
        public String Phone { get; set; }
        public String Address { get; set; }
        public String UName { get; set; }
        public String PWord { get; set; }
        public int UID { get; set; }
        // create everything else here
    }
}
