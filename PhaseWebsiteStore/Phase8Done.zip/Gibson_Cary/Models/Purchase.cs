﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gibson_Cary.Models
{
    // used for sales recording.
    public class Purchase
    {
        public Person Person { get; set; }
        public Product Product { get; set; }

    }// end class
}// end namespace
