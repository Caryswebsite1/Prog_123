﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gibson_Cary.Models
{
    public class SalesTransaction
    {
        public int SalesID { get; set; }   // can't be null
        public int ProductID { get; set; }
        public int PersonID { get; set; }
        public DateTime SalesDataTime { get; set; }
        public int PQuantity { get; set; }

    }// end class

}// end namespace
