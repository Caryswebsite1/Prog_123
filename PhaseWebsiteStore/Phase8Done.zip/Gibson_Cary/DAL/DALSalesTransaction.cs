﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration; // read appsettings.json
using System.Data.SqlClient;
using Gibson_Cary.Models;

namespace Gibson_Cary.DAL
{
    /********************************************************************/
    // DALSalesTransaction Class:  Database Access Layer for 
    // Sales Transactions table in data base. 
    //
    // All functions called by the Gibson Controller.
    /********************************************************************/

    public class DALSalesTransaction
    {

            public IConfiguration configuration { get; }

            // Connection String.  Will be different if at school computer or home:
            // see also constructor below...
            private String connString = "";


            public DALSalesTransaction(IConfiguration myConfig)
            {
                configuration = myConfig;

                // if at my home computer:
                //connString = configuration.GetConnectionString("MyConnStr");

                // if at school computer:
                connString = configuration.GetConnectionString("MyConnStrBC");

            }


        /* *************************************************************************
         * OneClickBuy(int prodID, string UserID, int NumBought)
         * 
         * Description: Takes a product and adds it to the data base.
         * Called by: Gibson Controller, AddProduct function.
         * ************************************************************************** */
        public Purchase OneClickBuy(int prodID, int UserID, int NumBought)
        {
            SalesTransaction st = new SalesTransaction();
            st.PersonID = UserID;
            st.ProductID = prodID;
            st.PQuantity = NumBought;
            st.SalesDataTime = DateTime.Now;

            //this.AddTransaction(st);

            Purchase aPurchase = new Purchase();
            aPurchase.Person = new DALPerson(configuration).GetPerson(UserID.ToString());
            aPurchase.Product = new DALProduct(configuration).GetProduct(prodID.ToString());

            new DALProduct(configuration).UpdateInventory(prodID, (NumBought * -1)); // decrement inventory by bought amount

            return aPurchase;

        }// end OneClickBuy

        private void AddTransaction(SalesTransaction st)
        {
            throw new NotImplementedException();
        }
    }// end class

}// end namespace
