﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gibson_Cary.Models;
using Gibson_Cary.DAL;
using Microsoft.Extensions.Configuration; // read appsettings.json
using Microsoft.AspNetCore.Http;


namespace Gibson_Cary.Controllers
{
    public class GibsonController : Controller
    {
        private readonly IConfiguration configuration;

        public GibsonController(IConfiguration myConfig)
        {
            configuration = myConfig;
        }

        // ---------------INDEX -----------------------------------------
        public IActionResult Index()
        {
            return View();
        }


        // -------------------login related------------------------------
        public IActionResult LoginView()
        {
            return View("LoginView");
          
        }// end Login


        public IActionResult Login(Credentials c)
        {
            DALPerson dp = new DALPerson(configuration);
            Person myPerson = dp.CheckCredentials(c);  // want to get person model object back

            if(myPerson == null)
            {
                // wrong credientials
                return View("ErrorView");
            }
            else
            {
                // save person id to the session
                HttpContext.Session.SetString("personID", Convert.ToString(myPerson.UID));

                // set person's first name in the oneway ViewBag going to the view..
                ViewBag.UserFirstName = myPerson.FName;
                ViewBag.Welcome = "Welcome "+ myPerson.FName;

                // need welcome page here.
                return View("WelcomeView");
            }
            
        }// end Login



        //---------------- Add a User Related ----------------------------------
        public IActionResult AddUserView()
        {
            return View("AddUserView");
        }// end Login


        public IActionResult AddUser(Person aPerson)
        {
            // Add person to DB
            DALPerson dalP = new DALPerson(this.configuration);
            int pID = dalP.AddPerson(aPerson);

            aPerson.UID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("personID", Convert.ToString(pID));

            return View("WelcomeView");

        }// end AddUser


        // --------------------- PRODUCT RELATED -----------------------------------
        public IActionResult AddProductView()
        {
            return View("AddProductView");
        }// end Login



        public IActionResult AddProduct(Product aProduct)
        {
            // Add Product to DB
            DALProduct dalP = new DALProduct(this.configuration);
            int pID = dalP.AddProduct(aProduct);

            aProduct.PID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("ProductID", Convert.ToString(pID));

            return View("AddAnotherProduct");

        }// end AddUser

        /*
        public IActionResult AddProduct(Product aProduct)
        {
            // Add Product to DB
            DALProduct dalP = new DALProduct(this.configuration);
            int pID = dalP.AddProduct(aProduct);

            aProduct.PID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("ProductID", Convert.ToString(pID));

            return View("AddAnotherProductView");

        }// end AddUser

    */
    }// end class
}