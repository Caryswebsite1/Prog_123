﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration; // read appsettings.json
using System.Data.SqlClient;
using Gibson_Cary.Models;

namespace Gibson_Cary.DAL
{
    public class DALProduct
    {

        public IConfiguration configuration { get; }

        public DALProduct(IConfiguration myConfig)
        {
            configuration = myConfig;
        }



        public int AddProduct(Models.Product aProduct)
        {
            // use scope identity.  return Product id of Product just added.
            int pID = 0;

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all Product data..
            String squery1 = "INSERT INTO [dbo].[Products]([Name],[Description],[Price],[InventoryAmount])VALUES(@Name, @Description, @Price, @InventoryAmount) select SCOPE_IDENTITY() as id;";
            //String squery2 = "INSERT INTO [dbo].[Credentials]([ProductID],[Password])VALUES(@pid, @pword) select SCOPE_IDENTITY() as id;";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("@Name", aProduct.Name);
            sCmd.Parameters.AddWithValue("@Description", aProduct.Description);
            sCmd.Parameters.AddWithValue("@Price", aProduct.Price);
            sCmd.Parameters.AddWithValue("@InventoryAmount", aProduct.InventoryAmount);
           

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();
            sReader.Read();
            pID = Convert.ToInt32(sReader[0].ToString());


            // 4. Close the connection
            sqlCon.Close();

            return pID;
        }// end AddProduct


        /*
        internal Product CheckCredentials(Credentials c)
        {
            Product aProduct = null;

            // first check to make sure we have input!
            if (c.UserName == null || c.PassWord == null)
            {
                // no input.  just return null!
                return aProduct;
            }
            // if made it to here, we at least have something to search for.

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            string query = "SELECT Product.ProductID, Product.FName from Product " +
                "inner join Credentials on Product.ProductID = Credentials.ProductID " +
                "where Product.UserName = @UserName AND Credentials.Password = @Password";

            SqlCommand sCmd = new SqlCommand(query, sqlCon);
            sCmd.Parameters.AddWithValue("@UserName", c.UserName);
            sCmd.Parameters.AddWithValue("@Password", c.PassWord);

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();


            if (sReader.Read())
            {
                aProduct = new Product();
                aProduct.UID = Convert.ToInt32(sReader["ProductID"].ToString());
                aProduct.FName = sReader["FName"].ToString();
            }

            // 4. Close the connection
            sqlCon.Close();

            return aProduct;
        }// end CheckCredentials
        */

        internal void deleteProduct(int pID)
        {
            //1. Create a connection

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: delete this Product data..
            String squery1 = "DELETE FROM [dbo].[Products] WHERE PID = @PID;";
                

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("@PID", pID);


            // 3. Run the command
            sCmd.ExecuteNonQuery();

            // 4. Close the connection
            sqlCon.Close();
        }// end deleteProduct



        internal void updateProduct(Product aProduct)
        {

            //1. Create a connection

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all Product data..
            String squery1 = "UPDATE [dbo].[Products]SET" +
                "[Name] = @Name, " +
                "[Description] = @Description, " +
                "[Price] = @Price, " +
                "[InventoryAmount] = @InventoryAmount, " +
                "WHERE PID = @PID;";


            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("Name", aProduct.Name);
            sCmd.Parameters.AddWithValue("Description", aProduct.Description);
            sCmd.Parameters.AddWithValue("Price", aProduct.Price);
            sCmd.Parameters.AddWithValue("InventoryAmount", aProduct.InventoryAmount);
            sCmd.Parameters.AddWithValue("PID", aProduct.PID);


            // 3. Run the command
            sCmd.ExecuteNonQuery();

            // 4. Close the connection
            sqlCon.Close();

        }// end update Product

        internal Product GetProduct(string ProductID)
        {
            // 1. connect to DB
            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all Product data..
            String squery1 = "SELECT [Name],[Description],[Price],[InventoryAmount]" + "FROM [dbo].[Products] where PID = @PID";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("@PID", ProductID);

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();
            Product aProduct = new Product();

            if (sReader.Read())
            {
                // got something.
                aProduct.Name = sReader["Name"].ToString();
                aProduct.Description = sReader["Description"].ToString();
                aProduct.Price = Convert.ToInt64(sReader["Price"].ToString());
                aProduct.InventoryAmount = Convert.ToInt32(sReader["InventoryAmount"].ToString());
            }// end if


            // step 4 close connection
            sqlCon.Close();

            return aProduct;

        }// end GetProduct


    }// end class DALProduct
}// end namespace
