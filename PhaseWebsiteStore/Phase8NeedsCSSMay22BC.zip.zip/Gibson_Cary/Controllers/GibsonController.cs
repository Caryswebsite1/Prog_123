﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gibson_Cary.Models;
using Gibson_Cary.DAL;
using Microsoft.Extensions.Configuration; // read appsettings.json
using Microsoft.AspNetCore.Http;


namespace Gibson_Cary.Controllers
{
    /********************************************************************/
    // GibsonController Class:  Controller for Game Store Site
    // Holds all IActionResult calls for the site.  This includes calls
    // to the DALPerson and DALProduct classes.
    /********************************************************************/

    public class GibsonController : Controller
    {
        private readonly IConfiguration configuration;

        public GibsonController(IConfiguration myConfig)
        {
            configuration = myConfig;
        }

        /* *************************************************************************
         * Index()
         * 
         * Description: returns the main index view.
         * Called by: framework
         * ************************************************************************** */
        public IActionResult Index()
        {
            return View("Index");
        }


        /* *************************************************************************
         * LoginView()
         * 
         * Description: returns the login view page.
         * Called by: menu item on index (Landing page)
         * ************************************************************************** */
        public IActionResult LoginView()
        {
            return View("LoginView");
          
        }// end LoginView


        /* *************************************************************************
         * Login(Credentials c)
         * 
         * Description: Takes the credentials and calls DALPerson.CheckCredentials in
         * an attempt to verify them through the database as an allowed user.  If so,
         * then sets the session ID and returns the Welcome view.  If not, then returns
         * the error view.
         * 
         * Called by: submit button on LoginView page.
         * ************************************************************************** */
        public IActionResult Login(Credentials c)
        {
            DALPerson dp = new DALPerson(configuration);
            Person myPerson = dp.CheckCredentials(c);  // want to get person model object back

            if(myPerson == null)
            {
                // wrong credientials, set session id will be null so return errorview.
                return View("ErrorView");
            }
            else
            {
                // save person id to the session
                HttpContext.Session.SetString("personID", Convert.ToString(myPerson.UID));

                // set person's first name in the oneway ViewBag going to the view..
                ViewBag.UserFirstName = myPerson.FName;
                ViewBag.Welcome = "Welcome "+ myPerson.FName;

                // need welcome page here.
                return View("WelcomeView");
            }
            
        }// end Login



        /* *************************************************************************
         * AddUserView()
         * 
         * Description: returns the AddUserView page
         * Called by: menu item on index page (main landing page)
         * ************************************************************************** */
        public IActionResult AddUserView()
        {
            return View("AddUserView");
        }// end AddUserView



        /* *************************************************************************
         * AddUser(Person aPerson)
         * 
         * Description: Takes a Person object and calls DALPerson.AddPerson to add them
         * to the data base as a valid user.  It then sets the session ID and returns 
         * the Welcome view.  
         * 
         * Called by: submit button on AddUserView page.
         * ************************************************************************** */
        public IActionResult AddUser(Person aPerson)
        {
            // Add person to DB
            DALPerson dalP = new DALPerson(this.configuration);
            int pID = dalP.AddPerson(aPerson);

            aPerson.UID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("personID", Convert.ToString(pID));

            // set person's first name in the oneway ViewBag going to the view..
            ViewBag.UserFirstName = aPerson.FName;
            ViewBag.Welcome = "Welcome " + aPerson.FName;

            return View("WelcomeView");

        }// end AddUser


        // --------------------- PRODUCT RELATED -----------------------------------
        /* *************************************************************************
         * AddProductView()
         * 
         * Description: returns the AddProductView page
         * Called by: menu item on layout 
         * ************************************************************************** */
        public IActionResult AddProductView()
        {
            string PID = HttpContext.Session.GetString("personID");
            if (PID == null)
            {
                // person not logged in. reject!
                return View("ErrorView");
            }
            else
            {
                return View("AddProductView");
            }
        }// end AddProductView


        /* *************************************************************************
         * AddProduct(Product aProduct)
         * 
         * Description: Takes a Product object and calls DALProduct.AddProduct to add it
         * to the data base.  It then sets the session Product ID and returns 
         * the AddAnotherProductView.  
         * 
         * Called by: submit button on AddProductView page.
         * ************************************************************************** */
        public IActionResult AddProduct(Product aProduct)
        {
            // Add Product to DB
            DALProduct dalP = new DALProduct(this.configuration);
            int pID = dalP.AddProduct(aProduct);

            aProduct.PID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("ProductID", Convert.ToString(pID));

            // return to a view that shows the new product addition details and 
            // gives the user a link to add another.
            return View("AddAnotherProductView", aProduct);

        }// end AddProduct


        /* *************************************************************************
        * ShowProductsView()
        * 
        * Description: sets up data for and returns the ShowProductsView page
        * Called by: menu item on layout 
        * ************************************************************************** */
        public IActionResult ShowProductsView()
        {
            string PID = HttpContext.Session.GetString("personID");
            if (PID == null)
            {
                // person not logged in. reject!
                return View("ErrorView");
            }
            else
            {
                // put all games (products) in a linked list from the database.
                DALProduct dbProd = new DALProduct(configuration);
                LinkedList<Product> allGames = dbProd.GetAllProducts();

                return View(allGames);
                //return View("ShowProductsView", productArray);

            }


        }// end AddProductView


        /* *************************************************************************
         * OneClickBuy()
         * 
         * Description: Shows a list of all Games in store.  
         * 
         * Then... ???  have a delete?  have a buy?  
         * It then sets the session Product ID and returns 
         * the AddAnotherProductView.  
         * 
         * Called by: action button on ShowGamesView page.
         * ************************************************************************** */
        public IActionResult OneClickBuy(int prodPID)
        {
            string PID = HttpContext.Session.GetString("personID");
            if (PID == null)
            {
                // person not logged in. reject!
                return View("ErrorView");
            }
            else
            {
                // purchase the product.
                int numPurchased = 1;

                DALSalesTransaction dbSale = new DALSalesTransaction(configuration);
                Purchase aPurchase = dbSale.OneClickBuy(prodPID, Convert.ToInt32(PID), numPurchased);

                return View(aPurchase);
                
            }
 
        }// end OneClickBuy





        /*
        public IActionResult AddProduct(Product aProduct)
        {
            // Add Product to DB
            DALProduct dalP = new DALProduct(this.configuration);
            int pID = dalP.AddProduct(aProduct);

            aProduct.PID = pID;

            // save person id to the sesson
            HttpContext.Session.SetString("ProductID", Convert.ToString(pID));

            return View("AddAnotherProductView");

        }// end AddUser

    */
    }// end class
}