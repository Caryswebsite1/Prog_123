﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gibson_Cary.Models;
using Gibson_Cary.DAL;
using Microsoft.Extensions.Configuration; // read appsettings.json
using Microsoft.AspNetCore.Http;


namespace Gibson_Cary.Controllers
{
    public class GibsonController : Controller
    {
        private readonly IConfiguration configuration;

        public GibsonController(IConfiguration myConfig)
        {
            configuration = myConfig;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Login(Credentials c)
        {
            DALPerson dp = new DALPerson(configuration);
            Person myPerson = dp.CheckCredentials(c);  // want to get person model object back

            if(myPerson == null)
            {
                // wrong credientials
                return View("ErrorView");
            }
            else
            {
                // save person id to the session
                HttpContext.Session.SetString("personID", Convert.ToString(myPerson.UID));

                // need welcome page here.
                return View("WelcomeView");
            }
            
        }// end Login

    }// end class
}