﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration; // read appsettings.json
using System.Data.SqlClient;
using Gibson_Cary.Models;

namespace Gibson_Cary.DAL
{
    public class DALPerson
    {
        public IConfiguration configuration { get;  }

        public DALPerson(IConfiguration myConfig)
        {
            configuration = myConfig;
        }



        public int AddPerson(Models.Person aPerson)
        {
            // use scope identity.  return person id of person just added.
            int pID = 0;

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all person data..
            String squery1 = "INSERT INTO [dbo].[Person]([FName],[LName],[email],[phone],[address],[UserName])VALUES(@fname, @lname, @email, @phone, @address, @uname) select SCOPE_IDENTITY() as id;";
            String squery2 = "INSERT INTO [dbo].[Credentials]([Password])VALUES(@pword) select SCOPE_IDENTITY() as id;";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("fname", aPerson.FName);
            sCmd.Parameters.AddWithValue("lname", aPerson.LName);
            sCmd.Parameters.AddWithValue("email", aPerson.Email);
            sCmd.Parameters.AddWithValue("phone", aPerson.Phone);
            sCmd.Parameters.AddWithValue("address", aPerson.Address);
            sCmd.Parameters.AddWithValue("uname", aPerson.UName);

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();
            sReader.Read();
            pID = Convert.ToInt32(sReader[0].ToString());


            // Additional for credentials (password)
            SqlCommand sCmd2 = new SqlCommand(squery2, sqlCon);
            sCmd2.Parameters.AddWithValue("pword", aPerson.PWord);

            // dont need to read unless we want to confirm pid.

            // 4. Close the connection
            sqlCon.Close();


            return pID;
        }// end AddPerson



        internal void deletePerson(int pUID)
        {
            //1. Create a connection

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all person data..
            String squery1 = "DELETE FROM [dbo].[Credentials] WHERE PersonID = @PersonID;" +
                "DELETE FROM [dbo].[Person] WHERE [PersonID] = @PersonID;";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("PersonID", pUID);


            // 3. Run the command
            sCmd.ExecuteNonQuery();

            // 4. Close the connection
            sqlCon.Close();
        }// end deletePerson



        internal void updatePerson(Person aPerson)
        {

            //1. Create a connection

            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all person data..
            String squery1 = "UPDATE [dbo].[Person]SET" +
                "[FName] = @fname, " +
                "[LName] = @lname, " +
                "[email] = @email, " +
                "[phone] = @phone, " +
                "[address] = @address " +
                "WHERE PersonID = @PersonID;";

                
            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("fname", aPerson.FName);
            sCmd.Parameters.AddWithValue("lname", aPerson.LName);
            sCmd.Parameters.AddWithValue("email", aPerson.Email);
            sCmd.Parameters.AddWithValue("phone", aPerson.Phone);
            sCmd.Parameters.AddWithValue("address", aPerson.Address);
            sCmd.Parameters.AddWithValue("PersonID", aPerson.UID);


            // 3. Run the command
            sCmd.ExecuteNonQuery();
            
            // 4. Close the connection
            sqlCon.Close();
           
        }// end update person

        internal Person GetPerson(string personID)
        {
            // 1. connect to DB
            // if at my home computer:
            //String connString = configuration.GetConnectionString("MyConnStr");

            // if at school computer:
            String connString = configuration.GetConnectionString("MyConnStrBC");

            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all person data..
            String squery1 = "SELECT [FName],[LName],[email],[phone],[address],[UserName]" + "FROM [dbo].[Person] where PersonID = @pID";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("@pID", personID);

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();
            Person aPerson = new Person();

            if (sReader.Read())
            {
                // got something.
                aPerson.FName = sReader["FName"].ToString();
                aPerson.LName = sReader["LName"].ToString();
                aPerson.Email = sReader["email"].ToString();
                aPerson.Phone = sReader["phone"].ToString();
                aPerson.Address = sReader["address"].ToString();
                aPerson.UName = sReader["UserName"].ToString();
                
            }// end if
            

            // step 4 close connection
            sqlCon.Close();

            return aPerson;

        }// end GetPerson

    }// end class DALPerson
}// end namespace
