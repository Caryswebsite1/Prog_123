﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration; // read appsettings.json
using System.Data.SqlClient;  

namespace Gibson_Cary.DAL
{
    public class DALPerson
    {
        public IConfiguration configuration { get;  }

        public DALPerson(IConfiguration myConfig)
        {
            configuration = myConfig;
        }

        public int AddPerson(Models.Person aPerson)
        {
            // use scope identity.  return person id of person just added.
            int pID = 0;

            // 1. connect to DB
            String connString = configuration.GetConnectionString("MyConnStr");
            SqlConnection sqlCon = new SqlConnection(connString);
            sqlCon.Open();

            // 2. create a command: insert all person data..
            String squery1 = "INSERT INTO [dbo].[Person]([FName],[LName],[email],[phone],[address],[UserName])VALUES(@fname, @lname, @email, @phone, @address, @uname) select SCOPE_IDENTITY() as id;";
            String squery2 = "INSERT INTO [dbo].[Credentials]([Password])VALUES(@pword) select SCOPE_IDENTITY() as id;";

            SqlCommand sCmd = new SqlCommand(squery1, sqlCon);
            sCmd.Parameters.AddWithValue("fname", aPerson.FName);
            sCmd.Parameters.AddWithValue("lname", aPerson.LName);
            sCmd.Parameters.AddWithValue("email", aPerson.Email);
            sCmd.Parameters.AddWithValue("phone", aPerson.Phone);
            sCmd.Parameters.AddWithValue("address", aPerson.Address);
            sCmd.Parameters.AddWithValue("uname", aPerson.UName);

            // 3. Query the DB
            SqlDataReader sReader = sCmd.ExecuteReader();
            sReader.Read();
            pID = Convert.ToInt32(sReader[0].ToString());


            // Additional for credentials (password)
            SqlCommand sCmd2 = new SqlCommand(squery2, sqlCon);
            sCmd2.Parameters.AddWithValue("pword", aPerson.PWord);

            // dont need to read unless we want to confirm pid.

            // 4. Close the connection
            sqlCon.Close();


            return pID;
        }// end AddPerson

    }// end class DALPerson
}// end namespace
