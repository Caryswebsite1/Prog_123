﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Gibson_Cary.Models;
using Gibson_Cary.DAL;
using Microsoft.Extensions.Configuration; // read appsettings.json

namespace Gibson_Cary.Controllers
{
    

    public class HomeController : Controller
    {
        private readonly IConfiguration configuration;

        public HomeController(IConfiguration myConfig)
        {
            configuration = myConfig;
        }


        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Page2(Person aPerson)
        {
            //String connString = configuration.GetConnectionString("MyConnStr");

            // Add person to DB
            DALPerson dalP = new DALPerson(this.configuration);
            int pID = dalP.AddPerson(aPerson);

            aPerson.UID = pID;

            return View(aPerson);
        }
    }
}
